# Main Streamlit app

import streamlit as st

st.title('EduBot AI')
st.write('Welcome to the AI-powered Education Assistant!')