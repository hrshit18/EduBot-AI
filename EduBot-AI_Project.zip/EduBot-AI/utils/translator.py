# Translator utility

def translate_text(text, lang):
    return f'Translated text in {lang}'