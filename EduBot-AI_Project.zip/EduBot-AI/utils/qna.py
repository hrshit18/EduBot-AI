# Q&A generator

def generate_questions(text):
    return ['What is AI?', 'Define Azure.']