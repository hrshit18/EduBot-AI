# Text-to-speech utility

def text_to_speech(text):
    print('Speaking:', text)