# OCR utility using Azure Vision

def extract_text(image_path):
    return 'Sample extracted text'