# Summarizer utility

def summarize_text(text):
    return 'This is a summary.'